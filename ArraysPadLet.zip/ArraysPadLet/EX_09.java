package AULA10;
import java.util.Arrays;
/*Criar dois vetores A e B cada um com 10 elementos inteiros. Construir um
vetor C, onde cada elemento de C � a divis�o dos respectivos elementos em
A e B.*/
public class EX_09 {

	public static void main(String[] args) {
		double vetorA[] = {1,2,3,4,5,6,7,8,9,10};
		double vetorB[] = {10,9,8,7,6,5,4,3,2,1};
		double vetorC[] = new double[10];
		
		for(int i = 0; i < 10; i++){	
			vetorC[i] = vetorA[i] / vetorB[i];
		}
		System.out.println(Arrays.toString(vetorC));
	}	
}
