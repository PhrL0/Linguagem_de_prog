package AULA10;
import java.util.Arrays;
/*Ler dois vetores A e B com 10 elementos cada. Construir um vetor C, sendo
este a jun��o dos dois outros vetores. Os primeiros 10 elementos de C
dever�o receber os elementos de A e os �ltimos elementos C dever�o
receber os elementos de B. Desta forma, C dever� ter o dobro de elementos
de A e B, ou seja, 20 elementos.*/
public class EX_23 {

	public static void main(String[] args) {
		int vetorA[] = {1,2,3,4,5,6,7,8,9,10};
		int vetorB[] = {11,12,13,14,15,16,17,18,19,20};
		int vetorC[] = new int[20];

		for(int i = 0; i < 10; i++) {
			vetorC[i] = vetorA[i];
		}
		for(int i = 0; i < 10; i++) {
			vetorC[i + 10] = vetorB[i];
		}
		System.out.println(Arrays.toString(vetorC));]
	}

}
