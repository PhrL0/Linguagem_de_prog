package AULA10;
/*Criar um vetor A com 5 elementos inteiros. Escreva um programa que
imprima a tabuada de cada um dos elementos do vetor A.*/
public class EX_25 {

	public static void main(String[] args) {
		
		int vetorA[] = {1,2,3,4,5};
		
		for(int i = 0; i < 5; i++) {
			System.out.println("");
			for(int j = 0; j <= 10; j++) {
				System.out.println(vetorA[i] + " x " + j + " = " + (vetorA[i] * j ));
			}
		}


	}

}
