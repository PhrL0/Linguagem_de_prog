package AULA10;
import java.util.Scanner;
/*Capture do teclado valores para preenchimento de uma matriz M (3 x 3).
Ap�s a captura imprima a matriz criada e encontre a quantidade de n�meros
pares, a quantidade de n�meros �mpares.*/
public class EX_32 {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		int matrizM[][] = new int[3][3];
		int par = 0, impar = 0;
		
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print("Digite um valor inteiro:");
				matrizM[i][j] = leitor.nextInt();
				if(matrizM[i][j] % 2 == 0) {
					par++;
				}
				else {
					impar++;
				}
			}
		}
		System.out.println();
		for(int i = 0; i < 3; i++) {
			for(int j = 0; j < 3; j++) {
				System.out.print(matrizM[i][j] + "  ");
			}
			System.out.print("\n");
		}
		System.out.println();
		System.out.println("A quantidade de n�meros pares �: " + par);
		System.out.println("A quantidade de n�meros impares �: " + impar);
	
		
		leitor.close();
		

	}

}
