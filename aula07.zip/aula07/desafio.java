package listaExercicio;

import java.util.Scanner;
import java.util.Random;

public class desafio {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		Random gerador = new Random();
		
		System.out.print("Digite o n�mero de jogos:");
		int jogos = leitor.nextInt();
		
		for(int i = 1; i <= jogos; i++) {
			System.out.print("Jogo " + i + ":");
			for(int j = 1; j <= 6; j++){
				System.out.print(" " + gerador.nextInt(60));
			}
			System.out.println();
		}
		
		

	}

}
