package listaExercicio;

import java.util.Scanner;
public class eXEMPLOwhile {

	public static void main(String[] args) {
		
		
		Scanner leitor = new Scanner(System.in);
		char repetir = 'S';
		//Estrutura While
		while(repetir == 'S' || repetir == 's') {
			System.out.println("Java � divertido!");
			System.out.print("Digite S ou s para repetir: ");
			repetir = leitor.next().charAt(0);
		}
		System.out.println("Voc� saiu do looping!");
		//Estrutura DoWhile
		do {
			System.out.println("Java � divertido!");
			System.out.print("Digite S ou s para repetir: ");
			repetir = leitor.next().charAt(0);
		}while(repetir == 'S' || repetir == 's');
		leitor.close();
	}

}
