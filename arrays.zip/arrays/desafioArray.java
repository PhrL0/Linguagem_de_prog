package arrayUnidimensional;
import java.util.Scanner;
public class desafioArray {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		
		double soma = 0;
		double media = 0;
		
		System.out.print("Digite o n�mero de pessoas: ");
		int valorNumPessoa = leitor.nextInt();
		
		double[] altura = new double[valorNumPessoa];
		
		for(int i = 0; i < valorNumPessoa; i++) {
			System.out.print("Altura da " + (i + 1) + "� pessoa:");
			double valorAlt = leitor.nextDouble();
			altura[i] = valorAlt;
			soma += altura[i];			
		}
		media = soma / valorNumPessoa;
		System.out.printf("A m�dia das alturas �: %.2f m \n",media);
		

		
		
		
		leitor.close();
	}

}
