package arrayUnidimensional;
public class arrayuni {

	public static void main(String[] args) {
		
		int i,j;
		int[] resultados = new int[11];
		
		for(i = 0; i < 11; i++) {
			resultados[i] = i * 7;
		}
		for(i = 0; i < 11; i++) {
			System.out.println("7 x " + i + " = " +  resultados[i]);
		}
	}

}
