import java.util.ArrayList;

public class ListaClasse {
    private ArrayList<String>listaDeCompras = new ArrayList<>();


    public void inseriritem(String item){
        listaDeCompras.add(item);
    }
    public boolean removerItem(String item){
        return listaDeCompras.remove(item);
    }
    public ArrayList<String> listarItens(){
        return listaDeCompras;
    }
}
