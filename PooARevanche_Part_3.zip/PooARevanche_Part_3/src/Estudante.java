import java.util.ArrayList;

public class Estudante {

    private ArrayList<Integer> ListaDenotas;
    private String nome;

    //construtor
    public Estudante(String nome){
        this.nome = nome;
        ListaDenotas = new ArrayList<>();
    }

    public String getNome(){
        return nome;
    }

    public void adicionarNota(int nota){
        ListaDenotas.add(nota);
    }

    public double calcularMedia(){
        double soma = 0;
        double media = 0;
        if(ListaDenotas == null){
            return 0.0;
        }
        for(double i : ListaDenotas){
            soma =  soma + i;
        }
        media = soma / ListaDenotas.size();
        return media;
    }


}
