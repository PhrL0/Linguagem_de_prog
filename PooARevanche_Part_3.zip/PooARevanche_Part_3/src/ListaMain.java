import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class ListaMain {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        ListaClasse listaDeCompra = new ListaClasse();

        int menu = 0;

        do {
            System.out.println("----------------");
            System.out.println("0. Sair");
            System.out.println("1. Inserir item");
            System.out.println("2. Remover item");
            System.out.println("3. Listar Itens");
            System.out.print("Digite uma opção: ");
            menu = scan.nextInt();

            if (menu == 1){
                //limpa buffer
                scan.nextLine();
                System.out.print("Digite o item:");
                String item = scan.nextLine();
                listaDeCompra.inseriritem(item);
            }
            else if (menu == 2){
                //limpa buffer
                scan.nextLine();
                System.out.print("Digite o item:");
                String item = scan.nextLine();
                if(listaDeCompra.removerItem(item)){
                    System.out.println("Item removido com sucesso!");
                }
                else{
                    System.err.println("Item não removido!");
                    continue;
                }
            }
            else if(menu == 3){
                for (String n :listaDeCompra.listarItens()){
                    System.out.println(n);
                }
            }

        }while(menu != 0);

        scan.close();

    }
}