import java.util.ArrayList;

public class ReferenciaValor {
    public static void main(String[] args) {

//        Integer x = 10;
//
//        int y = x;
//        System.out.println(y);
//        System.out.println("-------------");

        ArrayList<Integer> num = new ArrayList<>();

        num.add(10);
        num.add(20);

        System.out.println(num);


    }
}
