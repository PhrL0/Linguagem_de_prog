import java.util.ArrayList;

public class RegistroNotas {
    public static void main(String[] args) {

        ArrayList<Estudante> estudantes = new ArrayList<>();

        Estudante e1 = new Estudante("Pedro");
        Estudante e2 = new Estudante("Kawa");
        Estudante e3 = new Estudante("Matheus");

        e1.adicionarNota(78);
        e1.adicionarNota(87);
        e1.adicionarNota(90);

        e2.adicionarNota(60);
        e2.adicionarNota(50);
        e2.adicionarNota(90);

        e3.adicionarNota(90);
        e3.adicionarNota(0);
        e3.adicionarNota(30);

        estudantes.add(e1);
        estudantes.add(e2);
        estudantes.add(e3);

        for(Estudante estudante : estudantes){
            System.out.println("Estudante:" + estudante.getNome() + ", Nota: " + estudante.calcularMedia());
        }



    }
}
