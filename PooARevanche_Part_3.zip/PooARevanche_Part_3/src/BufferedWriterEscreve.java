import java.util.ArrayList;

public class BufferedWriterEscreve {
    public static void main(String[] args) {
        String path = "C:\\Users\\Aluno\\Desktop\\dados\\teste.csv";

        ArrayList<String> teste = new ArrayList<>();

        teste.add("nome","sobrenome");
        teste.add("Paula","Nunes");


    }
}
