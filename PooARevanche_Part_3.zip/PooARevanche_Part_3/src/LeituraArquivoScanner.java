import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class LeituraArquivoScanner {
    public static void main(String[] args) {
        File path = new File("C:\\Users\\Aluno\\Desktop\\dados\\funcionarios.csv");

        Scanner scanner = null;

        try {
            scanner = new Scanner(path);

            while(scanner.hasNextLine()){
                System.out.println(scanner.nextLine());
            }
        }catch (IOException e){
            System.err.println("Erro: " + e.getMessage());
        } finally {
            if (scanner != null){
                scanner.close();
            }
        }

    }
}
