package AULA11;
import java.util.Scanner;
public class funcaoComParametroEretorno {

	public static void main(String[] args) {
		double massa,altura,imc;
		
		Scanner leitor = new Scanner(System.in);
		System.out.print("Digite sua massa em quilograma:");
		massa = leitor.nextDouble();
		System.out.print("Digite sua altura em metros:");
		altura = leitor.nextDouble();
		
		imc = calculaImc(massa,altura);
		
		System.out.printf("Seu IMC �: %.2f", imc);
	}
	
	public static double calculaImc(double massa, double altura) {
		double aux;
		aux = massa / Math.pow(altura, 2);
		return aux;
	}

}
