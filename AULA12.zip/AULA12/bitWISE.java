package AULA11;

public class bitWISE {

	public static void main(String[] args) {
		int n1 = 40;
		int n2 = 31;
		
		System.out.println(n1 & n2);
		System.out.println(n1 | n2);
		System.out.println(n1 ^ n2);
	}

}
