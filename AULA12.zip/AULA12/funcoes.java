package AULA11;

public class funcoes {

	public static void main(String[] args) {
		saudacao();
	}
	public static void saudacao() {
		System.out.println("Ol� seja bem-vindo!");
	}
}
