package AULA11;
import java.util.Scanner;
public class Conversor {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		System.out.print("Digite um valor inteiro de 0 a 65535:");
		int valorDecimal = leitor.nextInt();
		int mascara = 0;
		
		for(int i = 15; i >= 0; i--) {
			mascara = (int)(Math.pow(2, i));
			int z = valorDecimal & mascara;
			if(z == 0){
				System.out.print(0);
			}
			else{
				System.out.print(1);
			}
			if(i % 4 ==0) {
				System.out.print(" ");
			}
		}
		
		
		
		
		
		leitor.close();

	}

}
