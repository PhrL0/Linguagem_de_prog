package AULA11;
import java.util.Scanner;
public class funcaoParametro {

	public static void main(String[] args) {
		String nome;
		Scanner leitor = new Scanner(System.in);
		System.out.print("Digite seu nome:");
		nome = leitor.nextLine();
		saudacao(nome);
		
		leitor.close();

	}
	public static void saudacao(String name) {
		System.out.println("Ol� " + name + " vamos tomar um caf�?!");
	} 
}
