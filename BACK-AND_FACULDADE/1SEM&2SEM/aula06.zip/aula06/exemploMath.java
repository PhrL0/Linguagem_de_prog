package aula06;

import java.util.Scanner;

public class exemploMath {

	public static void main(String[] args) {
		Scanner leitor = new Scanner(System.in);
		
		System.out.print("Digite um n�mero:");
		double x = leitor.nextDouble();
		
		if(x < 0) {
			System.out.println("Negativo");
			x = Math.abs(x);
		}
		
		System.out.printf("O n�mero �: %.2f\n", x);
		
		double raiz = Math.sqrt(x);
		System.out.println("A raiz �: " + raiz);
		
		double cubo = Math.pow(x, 3);
		System.out.printf("o cubo �: %.2f\n", cubo);
		
		int sorte =(int)(Math.random() * 100);
		System.out.println("O n�mero da sorte �:" + sorte);
		
		
		
		
		
		
		leitor.close();
		

	}

}
