package aula06;

import java.util.Locale;
import java.util.Scanner;

public class ExemploLocale {

	public static void main(String[] args) {
		//Locale.setDefault(Locale.US);
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.print("Digite um n�mero:");
		double x = leitor.nextDouble();
		
		System.out.println("O valor �: " + x);
		System.out.printf("O valor �:  %.2f\n" , x);
		
		
		leitor.close();

	}

}
