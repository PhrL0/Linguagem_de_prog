package aula06;

public class estruturaRep {

	public static void main(String[] args) {
		 int contador = 0;
		
		for(int i = 1;i <= 100; i++) {
			double pol = i * 25.4;
			System.out.printf(i +" polegada � igual a %.2f\n",pol);
			contador++;
			if(contador % 10 == 0) {
				System.out.println("");
			}
		}

	}

}
