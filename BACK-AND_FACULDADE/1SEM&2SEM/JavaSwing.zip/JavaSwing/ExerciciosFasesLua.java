package Screens;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ExerciciosFasesLua extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	String[] lua = {"", "Nova", "Crescente", "Cheia", "Minguante"};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExerciciosFasesLua frame = new ExerciciosFasesLua();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExerciciosFasesLua() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1049, 554);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel LabelImagem = new JLabel("");
		LabelImagem.setBounds(396, 54, 225, 225);
		contentPane.add(LabelImagem);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch(comboBox.getSelectedIndex()) {
				case 0:
					ImageIcon img4 = new ImageIcon("");
					LabelImagem.setIcon(img4);
					break;
				case 1:
					ImageIcon img = new ImageIcon("imagens/nova.png");
					LabelImagem.setIcon(img);
					break;
				case 2:
					ImageIcon img1 = new ImageIcon("imagens/crescente.png");
					LabelImagem.setIcon(img1);
					break;
				case 3:
					ImageIcon img2 = new ImageIcon("imagens/cheia.png");
					LabelImagem.setIcon(img2);
					break;
				case 4:
					ImageIcon img3 = new ImageIcon("imagens/minguante.png");
					LabelImagem.setIcon(img3);
					break;
				}
				
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(lua));
		comboBox.setBounds(388, 366, 241, 60);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("SELECIONE A FASE DA LUA:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(383, 325, 251, 30);
		contentPane.add(lblNewLabel_1);
	}

}
