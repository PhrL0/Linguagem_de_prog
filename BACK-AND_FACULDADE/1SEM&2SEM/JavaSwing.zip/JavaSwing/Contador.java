package Screens;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Contador extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtValorAtual;

	int contador = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Contador frame = new Contador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Contador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Contador:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(27, 112, 95, 82);
		contentPane.add(lblNewLabel);

		txtValorAtual = new JTextField();
		txtValorAtual.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtValorAtual.setText("0");
		txtValorAtual.setBounds(126, 137, 187, 41);
		contentPane.add(txtValorAtual);
		txtValorAtual.setColumns(10);

		JButton btnUp = new JButton("UP");
		btnUp.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnUp.setBounds(323, 137, 63, 41);
		contentPane.add(btnUp);
		
		btnUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contador = Integer.parseInt(txtValorAtual.getText());
				contador += 1;
				txtValorAtual.setText("" + contador);	
			}
		});
	}
}
