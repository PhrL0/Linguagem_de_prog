package Screens;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExemploJComboBox extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	String[] dia = {"Domingo", "Segunda", "Ter\u00E7a", "Quarta", "Quinta", "Sexta", "S\u00E1bado"};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExemploJComboBox frame = new ExemploJComboBox();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExemploJComboBox() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Escolha um dia da semana:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 28, 327, 36);
		contentPane.add(lblNewLabel);
		
		JComboBox cmdDiaDaSemana = new JComboBox();
		
		cmdDiaDaSemana.setModel(new DefaultComboBoxModel(dia));
		cmdDiaDaSemana.setFont(new Font("Tahoma", Font.PLAIN, 20));
		cmdDiaDaSemana.setBounds(20, 75, 230, 50);
		contentPane.add(cmdDiaDaSemana);
		
		JLabel lblMensagem = new JLabel("");
		lblMensagem.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblMensagem.setBounds(20, 149, 406, 50);
		contentPane.add(lblMensagem);
		
		cmdDiaDaSemana.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblMensagem.setText(cmdDiaDaSemana.getSelectedItem() + " � o " + (cmdDiaDaSemana.getSelectedIndex() + 1) + "� dia da semana.");
			}
		});
	}
}
