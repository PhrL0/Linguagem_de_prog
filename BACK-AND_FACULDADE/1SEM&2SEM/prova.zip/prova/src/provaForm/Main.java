package provaForm;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca();

       Livro livro1 = new Livro("Senhor dos Aneis","J. R. R. Tolkien",18921973);
       Livro livro2 = new Livro("Can't hurt me","David Goggins",17021975);
       Usuario usuario1 = new Usuario("Pedro Henrique");
       Usuario usuario2 = new Usuario("Kawã Gabriel");

       biblioteca.cadastraLivro(livro1);
       biblioteca.cadastraUsuario(usuario1);
       biblioteca.cadastraLivro(livro2);
       biblioteca.cadastraUsuario(usuario2);
//       biblioteca.emprestarLivro(usuario1,livro1);
//       biblioteca.emprestarLivro(usuario2,livro2);
//       for(Livro l : biblioteca.getListaDeLivros()){
//           System.out.println("Titulo: "+ l.getTitulo()+"\n Autor: "+ l.getAutor()+ "\n ISBN: "+ l.getIsbn() + "\n Disponivel: " + l.isDisponivel());
//           System.out.println("==========================================================");
//       }
       //biblioteca.devolucaoLivro(usuario1,livro1);
       //biblioteca.emprestarLivro(usuario2,livro1);
        biblioteca.VerificaLivrosDisponiveis();

    }
}