package provaForm;

import java.util.ArrayList;
import java.util.Random;

public class Usuario {
    Random random = new Random();
    private String nome;
    private ArrayList<Livro> listaLivroEmprestado;


    //construtor
    public Usuario(String nome){
        this.nome = nome;
        listaLivroEmprestado = new ArrayList<Livro>();
    }

    //get and setters nome
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    //get and setters numero de registro

    public ArrayList<Livro> getListaLivroEmprestado() {
        return listaLivroEmprestado;
    }

    public void setListaLivroEmprestado(Livro livro) {
        this.listaLivroEmprestado.add(livro);
    }

}

