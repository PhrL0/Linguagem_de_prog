package contiArray;

public class novasClasses {

	public static void main(String[] args) {
		int[] A  = {2,7,9,1,5,6,3};
		int[] B = new int[7];
		System.out.println(A.length);
		//B = A.clone();
		B = A;
		A[3] = 100;
		
		for (int i: A) {
			System.out.print(i + "\t");
		}
		System.out.println();
		for (int i: B) {
			System.out.print(i + "\t");
		}
	}

}
