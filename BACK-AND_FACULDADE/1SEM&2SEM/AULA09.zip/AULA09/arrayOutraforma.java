package contiArray;

public class arrayOutraforma {

	public static void main(String[] args) {
		
		//int[] arrey = new int[5];
		
		//boolean[] arreyBoo = new boolean[5];
		
		//String[] arreyString = new String[5];
		
		int[] arrey = {}
		for(int i: arrey) {
			System.out.println(i + "");
		}
		for(boolean i: arreyBoo) {
			System.out.println(i + "");
		}
		for(String i: arreyString) {
			System.out.println(i + "");
		}
	}

}
