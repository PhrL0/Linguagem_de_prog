package contiArray;

import java.util.Scanner;

public class desafioHash {

	public static void main(String[] args) {

		Scanner leitor = new Scanner(System.in);

		int[] vetor = new int[10];

		int busca = 0;
		boolean achou = false;
		for (int i = 0; i < 10; i++) {
			vetor[i] = (int) (Math.random() * 99);
			System.out.println(vetor[i]);
		}
		System.out.print("Digite um n�mero a ser encontrado: ");
		busca = leitor.nextInt();
		for (int i = 0; i < 10; i++) {
			if (busca == vetor[i]) {
				achou = true;
				break;
			}
		}
		
		if (achou) {
			System.out.println("ENCONTRADO");
		} else {
			System.out.println("N�O ENCONTRADO");
		}

		leitor.close();
	}
}