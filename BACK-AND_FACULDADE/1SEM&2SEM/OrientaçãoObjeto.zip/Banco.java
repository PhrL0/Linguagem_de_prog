package POO;

public class Banco {
	int numero;
	float saldo;
	float chequeEspecial;
	
	public Banco(int numero, float saldo, float chequeEspecial) {
		this.numero = numero;
		this.saldo = saldo;
		this.chequeEspecial = chequeEspecial;
	}
	
	void deposito(float dinheiro) {
		this.saldo += dinheiro;
		System.out.println("Dinheiro depositado com sucesso!");
	}
	
	void consultaSaldo() {
		System.out.println("R$" + this.saldo);
	}
	
	void saque(float quantia) {
		if((this.saldo + this.chequeEspecial) >= quantia) {
			this.saldo = this.saldo - quantia;
		}
		else {
			System.out.println("Operação negada!");
		}
	}
}
