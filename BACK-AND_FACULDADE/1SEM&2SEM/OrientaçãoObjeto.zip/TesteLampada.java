package POO;
import java.util.Scanner;
public class TesteLampada {

	public static void main(String[] args) {
		
		Lampada lampada = new Lampada(true);
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Interruptor: ");
		lampada.estado = scan.nextBoolean();
		
		lampada.interruptor();
		scan.close();
		

	}

}
