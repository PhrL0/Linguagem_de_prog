package POO;

public class Lampada {
	boolean estado;
	
	public Lampada(boolean estado) {
		this.estado = estado;
		
		}
	
	void interruptor () {
		if(this.estado) {
			System.out.println("Ligado");
		}
		else {
			System.out.println("Desligado");
		}
	}
	
}
