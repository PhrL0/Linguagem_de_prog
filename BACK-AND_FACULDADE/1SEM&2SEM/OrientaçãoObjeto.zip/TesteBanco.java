package POO;

public class TesteBanco {

	public static void main(String[] args) {
		
		Banco itau = new Banco(8,100,100);
	
		itau.consultaSaldo();
		itau.saque(101);
		itau.consultaSaldo();
		itau.deposito(1);
		itau.consultaSaldo();

	}

}
