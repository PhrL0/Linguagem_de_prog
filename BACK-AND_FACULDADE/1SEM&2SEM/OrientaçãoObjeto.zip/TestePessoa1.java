package POO;

public class TestePessoa1 {

	public static void main(String[] args) {
		 Pessoa1 p1 = new Pessoa1();
		 
		 p1.setAltura(1.9);
		 
		 
		 System.out.println(p1.getAltura());
	}

}
