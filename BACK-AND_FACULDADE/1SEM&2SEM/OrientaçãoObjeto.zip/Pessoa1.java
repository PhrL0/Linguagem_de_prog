package POO;

public class Pessoa1 {
	
	private String nome;
	private int idade;
	private double altura;
	private double massa;
	private boolean casado;
	
	public double getAltura() {
		return this.altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
}
