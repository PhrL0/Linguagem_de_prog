package POO;

public class TestePessoa {

	public static void main(String[] args) {
		Pessoa pedro = new Pessoa(20,"Pedro",true);
				
		System.out.println("Nome: " + pedro.nome);
		System.out.println("Idade: " + pedro.idade);
		System.out.println("Casado: " + pedro.casado);

	}

}
