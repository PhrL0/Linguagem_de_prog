package POO;

public class Pessoa {
	String nome;
	int idade;
	boolean casado;
	
	
	//construtor
	public Pessoa(int idade, String nome, boolean casado) {
		this.idade = idade;
		this.nome = nome;
		this.casado = casado;
	}
}


