package poo;

import java.util.Scanner;

public class TestePooArray {

	public static void main(String[] args) {
		PooArray mercado = new PooArray();
		Scanner scan = new Scanner(System.in);

		int aux = 0;
		int aux2;
		String removido;

		while (aux == 0) {

			System.out.println("Digite a operação que deseja\n0.Sair \n1.Remover item \n2.Inserir item \n3.Listar item");
			aux2 = scan.nextInt();
			switch (aux2) {
			case 0:
				aux = 1;
				break;
			case 1:
				System.out.print("Digite o valor:");
				scan.nextLine();
				removido = scan.nextLine();
				if(mercado.removeItem(removido)) {
					System.out.print("Item removido");
					break;
				}
				else {
					System.out.print("Item não encontrado");
					break;
				}
			case 2:
				System.out.print("Digite o valor:");
				scan.nextLine();
				mercado.inserirItem(scan.nextLine());
				break;
				
			case 3:
				for(String n: mercado.getLista()) {
					System.out.println(n);
				}
				
			}

		}
		scan.close();
	}

}
