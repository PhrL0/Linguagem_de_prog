package poo;

public class Casa {

	private String bairro;
	private String cor;
	private boolean possuiChurras;
	private double comprimento;
	private double largura;
	
	public Casa(String bairro, String cor, boolean possuiChurras, double comprimento, double largura){
		this.bairro = bairro;
		this.cor = cor;
		this.possuiChurras = possuiChurras;
		this.comprimento = comprimento;
		this.largura = largura;
	}
	public Casa() {
		
	}
	
	
	
	
	public String getBairro() {
		return bairro;
	}




	public void setBairro(String bairro) {
		this.bairro = bairro;
	}




	public String getCor() {
		return cor;
	}




	public void setCor(String cor) {
		this.cor = cor;
	}




	public boolean isPossuiChurras() {
		return possuiChurras;
	}




	public void setPossuiChurras(boolean possuiChurras) {
		this.possuiChurras = possuiChurras;
	}




	public double getComprimento() {
		return comprimento;
	}




	public void setComprimento(double comprimento) {
		this.comprimento = comprimento;
	}




	public double getLargura() {
		return largura;
	}




	public void setLargura(double largura) {
		this.largura = largura;
	}




	double calcPerimetro(double comprimento, double largura) {
		return (comprimento * 2) + (largura * 2);
	}
	
	double calcArea(double comprimento, double largura) {
		return comprimento * largura;
	}
	
	double calcPrecoCasa(double area,String bairro) {
		double valor = 0 ;
		
		switch(bairro) {
		case "Vila Nery":
			valor = area * 4500;
		case "Vila Prado":
			valor = area * 5000;
		case "Damha":
			valor = area * 10000;
		default:
			System.err.println("Bairro não encontrado na base de dados");
		}
		return valor;
	}
}