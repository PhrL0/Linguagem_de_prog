package poo;
import java.util.Scanner;
public class AlteraCasa {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		Casa casa1 = new Casa();
		
		int cont = 0;
		int aux;
		int aux2;
		
		while(cont == 0) {
			System.out.println("O que você deseja fazer:\n Digite 1 para alterar \n Digite 2 para vizualizar \n Digite 3 para Sair");
			aux = scan.nextInt();

			switch(aux) {
			case 1:
				System.out.println("Digite qual atributo alterar:\n Digite 1 para cor\n Digite 2 para Churrasqueira \n Digite 3 bairro \n Digite 4 para comprimento \n Digite 5 para largura");
				aux2 = scan.nextInt();
				switch(aux2) {
				case 1:
					System.out.println("Digite o valor:");
					casa1.setCor(scan.nextLine());
					
				case 2:
					System.out.println("Digite o valor:");
					casa1.setPossuiChurras(scan.nextBoolean());
					
				case 3:
					System.out.println("Digite o valor:");
					casa1.setBairro(scan.nextLine());
					
				case 4:
					System.out.println("Digite o valor:");
					casa1.setComprimento(scan.nextDouble());
					
				case 5:
					System.out.println("Digite o valor:");
					casa1.setLargura(scan.nextDouble());
					
				}
			case 2:
				System.out.println("Digite qual atributo vizualizar:\n Digite 1 para cor\n Digite 2 para Churrasqueira \n Digite 3 bairro \n Digite 4 para comprimento \n Digite 5 para largura");
				aux2 = scan.nextInt();
				switch(aux2) {
				case 1:
					System.out.println(casa1.getCor());
					break;
				case 2:
					System.out.println(casa1.isPossuiChurras());
					break;
				case 3:
					System.out.println(casa1.getBairro());
					break;
					
				case 4:
					System.out.println(casa1.getComprimento());
					break;
				case 5:
					System.out.println(casa1.getLargura());
					break;
					
				}
			case 3:
				cont = 1;
				break;
			}
			
		}

	}

}
