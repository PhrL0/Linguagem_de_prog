package poo;
import java.util.ArrayList;
public class ArrayListExemplo {

	public static void main(String[] args) {
		
		ArrayList<String> listaDeNomes = new ArrayList();
		
		listaDeNomes.add("Pedro");
		listaDeNomes.add("Kawa");
		listaDeNomes.add("Matheus");
		listaDeNomes.add("Larissa");
		listaDeNomes.add("Sophia");
		listaDeNomes.add("Henrique");
		listaDeNomes.add("Rodrigues");
		
		for(String n: listaDeNomes) {
			System.out.println();
		}
		
		
		listaDeNomes.remove(1);
		listaDeNomes.remove("Kawa");
		
		for(String n: listaDeNomes) {
			System.out.println(n);
		}
		
		
	}

}
