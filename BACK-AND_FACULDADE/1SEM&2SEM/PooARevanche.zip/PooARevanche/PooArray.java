package poo;

import java.util.ArrayList;

public class PooArray {
	private ArrayList<String> lista = new ArrayList<>();

	public ArrayList<String> getLista() {
		return lista;
	}

	public void inserirItem(String item) {
		lista.add(item);
	}
	
	public boolean removeItem(String item) {
		return lista.remove(item);
		}
}
