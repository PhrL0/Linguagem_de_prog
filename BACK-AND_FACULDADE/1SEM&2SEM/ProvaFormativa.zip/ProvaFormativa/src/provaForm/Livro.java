package provaForm;

public class Livro {
    private  String titulo;
    private String autor;
    private int isbn;
    private boolean disponivel;

    //construtor
    public Livro(String titulo, String autor, int isbn){
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.disponivel = true;
    }

    //metodos
    //get and setter titulo
    public String getTitulo() {
        return titulo;
    }
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    //get and setters autor
    public String getAutor(){
        return  autor;
    }
    public void setAutor(String autor){
        this.autor = autor;
    }
    //get and setters isbn
    public int getIsbn() {
        return isbn;
    }
    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }
    //get and setters disponivel
    public boolean isDisponivel() {
        return disponivel;
    }
    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

}
