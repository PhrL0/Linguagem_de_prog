package provaForm;

import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Livro> listaDeLivros = new ArrayList<>();
    private ArrayList<Usuario> listaDeUsuarios = new ArrayList<>();

    public void cadastraLivro(Livro livro){
        listaDeLivros.add(livro);
        System.out.println("livro cadastrado com sucesso!");
    }
    public void cadastraUsuario(Usuario usuario){
        listaDeUsuarios.add(usuario);
        System.out.println("Usuário cadastrado com sucesso!");
    }
    public ArrayList<Livro> getListaDeLivros() {
        return listaDeLivros;
    }
    public void emprestarLivro(Usuario usuario, Livro livro){
        if(livro.isDisponivel()){
            usuario.setListaLivroEmprestado(livro);
            livro.setDisponivel(false);
        } else {
            System.err.println("Livro indisponivel");
        }
    }

    public void devolucaoLivro(Usuario usuario, Livro livro){
        usuario.getListaLivroEmprestado().remove(livro);
    }


}
