package provaForm;

import java.util.ArrayList;

public class Usuario {
    private String nome;
    private int numeroRegistro;
    private ArrayList<Livro> listaLivroEmprestado;

    //construtor
    public Usuario(String nome,int numeroRegistro){
        this.nome = nome;
        this.numeroRegistro = numeroRegistro;
        listaLivroEmprestado = new ArrayList<Livro>();

    }

    //get and setters nome
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    //get and setters numero de registro

    public int getNumeroRegistro() {
        return numeroRegistro;
    }
    public void setNumeroRegistro(int numeroRegistro) {
        this.numeroRegistro = numeroRegistro;
    }

    public ArrayList<Livro> getListaLivroEmprestado() {
        return listaLivroEmprestado;
    }

    public void setListaLivroEmprestado(Livro livro) {
        this.listaLivroEmprestado.add(livro);
    }
}

