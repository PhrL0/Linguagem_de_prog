package Exercicio3;

public class TesteFiguras {
    public static void main(String[] args) {
        Triangulo t1 = new Triangulo();

        t1.setAltura(10);
        t1.setBase(5);

        System.out.println(t1.calcArea());
    }


}
