package Exercicio3;

public class Figura2D {
    private double base;
    private double altura;

    public double getAltura() {
        return altura;
    }

    public double getBase() {
        return base;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void setBase(float base) {
        this.base = base;
    }
}
