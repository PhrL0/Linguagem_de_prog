public class testeHerança {
    public static void main(String[] args) {
        Professor prof1 = new Professor();

        prof1.setNome("Kawa");
        System.out.println(prof1.getNome());
    }
}
