package JavaSwingPart2;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JcheckBox_JtextArea extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JcheckBox_JtextArea frame = new JcheckBox_JtextArea();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JcheckBox_JtextArea() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SELECIONE AS OP\u00C7\u00D5ES:");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(10, 11, 243, 50);
		contentPane.add(lblNewLabel);
		
		JCheckBox chckbxColesterol = new JCheckBox("COLESTEROL ALTO");
		chckbxColesterol.setFont(new Font("Tahoma", Font.PLAIN, 20));
		chckbxColesterol.setBounds(10, 83, 200, 23);
		contentPane.add(chckbxColesterol);
		
		JCheckBox chckbxDiabetes = new JCheckBox("DIABETES");
		chckbxDiabetes.setFont(new Font("Tahoma", Font.PLAIN, 20));
		chckbxDiabetes.setBounds(10, 127, 200, 23);
		contentPane.add(chckbxDiabetes);
		
		JCheckBox chckbxHipertensao = new JCheckBox("HIPERTENS\u00C3O");
		chckbxHipertensao.setFont(new Font("Tahoma", Font.PLAIN, 20));
		chckbxHipertensao.setBounds(10, 169, 165, 23);
		contentPane.add(chckbxHipertensao);
		
		JTextArea txtDicas = new JTextArea();
		txtDicas.setBounds(216, 72, 210, 180);
		contentPane.add(txtDicas);
		
		JButton btnDicas = new JButton("Dicas");
		
		btnDicas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDicas.setBounds(0, 215, 89, 37);
		contentPane.add(btnDicas);
		
		JButton btnSair = new JButton("Sair");
		
		btnSair.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnSair.setBounds(99, 215, 89, 37);
		contentPane.add(btnSair);
		
		
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnDicas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDicas.setText("");
				if(chckbxColesterol.isSelected()) {
					txtDicas.append("Evite ingerir gordura.\n");
				}
				if(chckbxDiabetes.isSelected()) {
					txtDicas.append("Evite ingerir a�ucar.\n");
				}
				if(chckbxHipertensao.isSelected()) {
					txtDicas.append("Evite ingerir sal.\n");
				}
				if (!chckbxColesterol.isSelected() && !chckbxDiabetes.isSelected() && !chckbxHipertensao.isSelected()) {
					txtDicas.append("Dieta sem restri��o");
				} 
			}
		});
	}
}
