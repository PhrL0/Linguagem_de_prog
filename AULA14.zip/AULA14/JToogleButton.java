package JavaSwingPart2;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JToogleButton extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JToogleButton frame = new JToogleButton();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JToogleButton() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 527);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Interruptor Digital");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel.setBounds(130, 13, 169, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lbIImagem = new JLabel("");
		lbIImagem.setBounds(82, 61, 264, 363);
		contentPane.add(lbIImagem);
		ImageIcon img = new ImageIcon("imagens/OFF.png");
		lbIImagem.setIcon(img);
		
		
		JToggleButton tglbtnOnOff = new JToggleButton("ON");
	
		tglbtnOnOff.setBounds(149, 437, 123, 42);
		contentPane.add(tglbtnOnOff);
		
		tglbtnOnOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!tglbtnOnOff.isSelected()) {
					ImageIcon img = new ImageIcon("imagens/ON.png");
					lbIImagem.setIcon(img);
					tglbtnOnOff.setText("OFF");
				}
				else {
					ImageIcon img = new ImageIcon("imagens/OFF.png");
					lbIImagem.setIcon(img);
					tglbtnOnOff.setText("ON");
				}
			}
		});
	}
}
